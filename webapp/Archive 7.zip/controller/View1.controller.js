sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function (Controller) {
	"use strict";

	return Controller.extend("mobilefinance.ZFI_Mobile_Finance.controller.View1", {
		onInit: function () {

		}
	});
});